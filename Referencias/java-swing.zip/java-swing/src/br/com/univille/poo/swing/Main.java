package br.com.univille.poo.swing;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        LoginFrame loginFrame = new LoginFrame();
    }

}
